from datetime import datetime
import discord
from discord.ext import commands






logs_guild = 1 # Логирования гильдий ([on_guild_join] и [on_guild_remove]) [Фалн находится в директории (.\logs\mainlog) ]
logs_member = 1 # Логирование пользователей ([on_member_join] и [on_member_remove]) [Фалн находится в директории (.\logs\mainlog) ]
logs_guildschat = 0 #Логирование чата с гильдии (on_message) [Фалн находится в директории (.\logs\mainlog\guilds\) ]

class logs(commands.Cog):
    def __init__(self, client):
        self.client = client

   #ON MEMEBR JOIN
    @commands.Cog.listener()
    async def on_member_join(self, member):
        if logs_member == 1:
            serverid = member.guild.id
            servername = member.guild

            with open(f"logs/mainlog/on-member-join-logs.log", "a", encoding = "utf-8") as file:
                file.write(f"[{datetime.utcnow()}]\n-=-\n🟢 Был зарегестрирован пользователь {member}. ID сервера: `{serverid}`. Название сервера: `{servername}`. Путем ивента on_member_join\n-=-\n")
        else:
            pass

    #ON MEMBER LEAVE
    @commands.Cog.listener()
    async def on_member_remove(self, member):
        if logs_member == 1:
            with open(f"logs/mainlog/on-member-remove-logs.log", "a", encoding = "utf-8") as file:
                file.write(f"[{datetime.utcnow()}]\n-=-\n🔴 Был удалён пользователь {member}. Путем ивента on_member_remove\n-=-\n")
        else:
            pass
    

    #ON GUILD JOIN
    @commands.Cog.listener()
    async def on_guild_join(self, guild):
        if logs_guild == 1:
            serverid = guild.id
            servername = guild.name

            with open(f"logs/mainlog/on-guild-join-logs.log", "a", encoding = "utf-8") as file:
                file.write(f"[{datetime.utcnow()}]\n-=-\n🟢 Бот был добавлен на сервер!\n`Название сервера:` {servername}\n`ID сервера:` {serverid}\n`Участников на сервере:` {len(guild.members)}\n`Серверов у бота:` {len(self.client.guilds)}\n-=-\n")
        else:
            pass


    #ON GUILD REMOVE
    @commands.Cog.listener()
    async def on_guild_remove(self, guild):
        if logs_guild == 1:
            serverid = guild.id
            servername = guild.name

            with open(f"logs/mainlog/on-guild-remove-logs.log", "a", encoding = "utf-8") as file:
                file.write(f"[{datetime.utcnow()}]\n-=-\n🔴 Бот был удалён с сервера!\n`Название сервера:` {servername}\n`ID сервера:` {serverid}\n`Участников на сервере:` {len(guild.members)}\n`Серверов у бота:` {len(self.client.guilds)}\n-=-\n")
        else:
            pass

    
    @commands.Cog.listener()
    async def on_message(self, message):
        if logs_guildschat == 1:
            with open(f"logs/mainlog/guilds/{message.guild.id}-chatlog.log", "a", encoding = "utf-8") as file:
                    file.write(f"Пользвоатель {message.author} написал: [ {message.content} ]\n-=--=-\n")
        else:
            pass


    


def setup(client):
    client.add_cog(logs(client))




#                                                                                                 ＥＸＡＭＰＬＥ ＬＯＧＳ １．３
#                                                                                                   ＭＡＤＥ ＣＯＤＥ＃７７１０