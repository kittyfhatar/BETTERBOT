from datetime import datetime
import disnake as discord
import random
import sdc_api_py
from disnake.ext import commands, tasks
from configs.config import status, prefix, lang, currency, version, versionid
from api.server import base, main
import psutil
import datetime, time


class OnReady(commands.Cog):
    def __init__(self, client):
        self.client = client

    @commands.Cog.listener()
    async def on_ready(self):
        #await self.client.change_presence(activity = discord.Activity(type = discord.ActivityType.watching, name = f"help | client"))
        print("ptero start") # [[ Для того чтобы птеродактиль определил что сервер прошел инициализацию и уже запущен ]] #
        print(f"\033[38;5;172m[{self.client.user.name}]\033[38;5;78m ➤\033[38;5;15m  Подключение\033[38;5;78m ✔\033[0;0m")
        print(f"\033[38;5;172m[{self.client.user.name}]\033[38;5;78m ➤\033[38;5;15m  Успешно подключился к серверам Discord \033[38;5;78m ✔\033[0;0m")
        print(f'\033[38;5;172m[{self.client.user.name}]\033[38;5;78m ➤\033[38;5;15m  ID: {self.client.user.id}\033[0;0m')
        global startTime
        startTime = time.time()        
        #self.status_task.start()

        client = sdc_api_py.Bots(self.client, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjkzNzQxMDAwMDcxMDY4NDcwMiIsInBlcm1zIjowLCJpYXQiOjE2NDM4MTA2MjN9.oxZPQl4ldBg_S0kbZnzv-K0S5ku0oEBLhW6KP1NSFfg')
        client.create_loop(31)

        for guild in self.client.guilds:
            print(guild.id , guild.name)

        channel = self.client.get_channel(versionid)
        await channel.edit(name = f'Версия: {version}')

        for guild in self.client.guilds:
            if base.guild(guild) is None:
                base.send(f"INSERT INTO guilds VALUES ('{guild.id}', '{guild.name}', '{prefix}', '{lang}', '{currency}', NULL, NULL, NULL, NULL, NULL, 3, 'mute')")
            else:
                pass
            
            for member in guild.members:
                if not member.bot:
                    try:
                        # * Включение логов в канал замедляет запись
                        serverid = member.guild.id
                        servername = member.guild.name
                        channell = self.client.get_channel(937678422438707200)
                        if base.user(member) is None:	
                            base.send(f"INSERT INTO users VALUES ('{guild.id}', '{member}', '{member.id}', 0, 0, 0, 0, 0)")
                            #await channell.send(embed = main.embed(f'Был зарегестрирован пользователь {member.mention}. ID сервера: `{serverid}`. Название сервера: `{servername}`. Путем ивента on_ready'))
                            if base.bages(member) is None:
                                base.send(f"INSERT INTO bages VALUES ('{member.name}', '{member.id}', 0, 0, 0, 0, 0, 0, 0)")                          
                        else:
                            pass
                    except:
                        continue
                        
    @commands.command(name='stats')
    async def _stats(self,ctx):
        uptime = str(datetime.timedelta(seconds=int(round(time.time()-startTime))))
        memory = psutil.virtual_memory().total / (1024.0 ** 3)
        await ctx.send(embed = discord.Embed(title = 'Информация', description = f'``` • Пинг          :: {round(self.client.latency * 1000)} \n • ОЗУ исп.      :: {round(memory)} MB \n • Аптайм бота   :: {uptime} \n\n • disnake       :: v{discord.__version__} \n • Версия бота   :: {version} ```'))                                                 

    #@tasks.loop(minutes = 0.2)
    #async def status_task(self):
        #await self.client.change_presence(activity = discord.Game(random.choice(status)))

def setup(client):
    client.add_cog(OnReady(client))